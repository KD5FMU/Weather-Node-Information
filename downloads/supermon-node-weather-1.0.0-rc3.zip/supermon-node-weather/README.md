# Supermon Node Weather 1.0.0 release candidate 3

Adds WeatherAPI.com conditions and optional local SkywarnPlus status to the **Node Information** cells in Supermon 8 on Debian ASL3. Set a U.S. ZIP per node. Weather is requested once every three minutes per distinct ZIP. The add-on reads SkywarnPlus once a minute. Active watches appear in red, warnings appear in orange, and the SkywarnPlus status matches their larger font while either is active.

## Install or update

Use the standard Supermon location at `/var/www/html/supermon` on an ASL3 host with PHP CLI and a running cron service. The installer checks the dashboard layout and installs `python3-yaml` if needed.

Download and extract the release archive on the ASL3 host. From the extracted `supermon-node-weather` directory, run:

```sh
sudo sh install.sh
```

Choose one node by ID or all local nodes detected in Supermon’s `allmon.ini`. All local mode selects numeric node entries that point to a loopback address. Enter a five-digit ZIP for each selected node. If you add a node later, rerun setup to include it. If the standard SkywarnPlus install is detected, the wizard offers it for each node. Enter your WeatherAPI.com key at the hidden prompt. Existing settings and a nonempty key are reused when upgrading, including upgrades from the prototype. Choose a fixed width for all node tables if you want them to stay aligned. The default fixed width is 1100 pixels. Text wraps and rows grow vertically. Narrow browser windows may scroll horizontally. On an existing installation, run `sudo sh install.sh --configure` to revisit the node and width choices. The key lives at `/etc/supermon-node-weather.key` with mode 0640, accessible to root and the Asterisk group.

Open Supermon and reload the page. To revise locations or specify a custom local SkywarnPlus path, edit `/etc/supermon-node-weather.json`. See `node-weather.example.json` for the format. A five-digit ZIP controls weather and SkywarnPlus uses the counties in its own configuration. To hide the legacy page-wide banner, optionally set `$NODE_WEATHER_HIDE_LEGACY = true;` in Supermon's PHP `global.inc`.

After a Supermon update, rerun the add-on installer if the updater replaced `link.php`. To test the display without touching the radio or SkywarnPlus, append `&testAlerts=NODE_ID` to a Supermon node URL for a configured node with SkywarnPlus enabled. The page labels both sample alerts TEST. Remove the parameter to return to live alerts.

## Uninstall

```sh
sudo supermon-node-weather-uninstall
```

This removes the add-on's PHP and JavaScript integration, collector, scheduled job and snapshot. It removes the add-on's edits from the current `link.php`, preserving other dashboard changes. It keeps the configuration and key for reinstall. To remove those too, use `sudo supermon-node-weather-uninstall --purge`. Backups are kept in `/var/backups/supermon-node-weather/`.

Sources [KD5FMU ASL3 Multi App Install](https://github.com/KD5FMU/ASL3_Multi_App_Install), [SkywarnPlus](https://github.com/Mason10198/SkywarnPlus), [WeatherAPI.com](https://www.weatherapi.com/docs/).
